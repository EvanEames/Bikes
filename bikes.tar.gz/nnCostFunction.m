function [J grad] = nnCostFunction(nn_params, input_layer_size, hidden_layer_size, num_labels, X, y, lambda)
%NNCOSTFUNCTION Implements the neural network cost function for a two layer
%neural network which performs classification
%   [J grad] = NNCOSTFUNCTON(nn_params, hidden_layer_size, num_labels, ...
%   X, y, lambda) computes the cost and gradient of the neural network. The
%   parameters for the neural network are "unrolled" into the vector
%   nn_params and need to be converted back into the weight matrices. 
% 
%   The returned parameter grad should be a "unrolled" vector of the
%   partial derivatives of the neural network.
%

% Reshape nn_params back into the parameters Theta1 and Theta2, the weight matrices for our 2 layer neural network
Theta1 = reshape(nn_params(1:hidden_layer_size * (input_layer_size + 1)), hidden_layer_size, (input_layer_size + 1));

Theta2 = reshape(nn_params((1 + (hidden_layer_size * (input_layer_size + 1))):end), num_labels, (hidden_layer_size + 1));

% Setup some useful variables
m = size(X, 1);
         
% We will be returning the gradient of Theta1 and Theta2
J = 0;

Theta1_grad = zeros(size(Theta1));
Theta2_grad = zeros(size(Theta2));

% Forwardprop
X = [ones(size(X, 1),1) X];
a1 = sigmoid(X*Theta1');
a1 = [ones(size(a1, 1),1) a1];
h = sigmoid(a1*Theta2');

% Calculate the cost function
J = (1/m)*(sum(-y.*log(h) - (1-y).*log(1-h)));

%These will be the theta matrices without the leading row of 1's
Theta1_tmp = Theta1(:,2:size(Theta1,2));
Theta2_tmp = Theta2(:,2:size(Theta2,2));

% Add the contribution from the regularization parameter
J = J + (lambda/(2*m))*(sum(sum(Theta1_tmp.^2))+sum(sum(Theta2_tmp.^2)));

%Backprop
Theta1_grad = zeros(hidden_layer_size,input_layer_size+1);
Theta2_grad = zeros(num_labels,hidden_layer_size+1);
for i=1:m
	a0 = X(i,:);
	a1 = [1 sigmoid(a0*Theta1')];
	h = sigmoid(a1*Theta2');
	delta3 = (h-y(i))';
	sig_grad = a1(2:end).*(1-a1(2:end));
	delta2 = Theta2_tmp'*delta3.*sig_grad';
	Theta1_grad = Theta1_grad + delta2*a0;
	Theta2_grad = Theta2_grad + delta3*a1;
end;
Theta1_grad = Theta1_grad./m + (lambda/m)*[zeros(size(Theta1_tmp, 1),1) Theta1_tmp];
Theta2_grad = Theta2_grad./m + (lambda/m)*[zeros(size(Theta2_tmp, 1),1) Theta2_tmp];
	

% -------------------------------------------------------------

% =========================================================================

% Unroll gradients
grad = [Theta1_grad(:) ; Theta2_grad(:)];

end
