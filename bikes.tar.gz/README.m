%ENGLISH (French below):
% The main program is found in bikes.m
% To call it, you simply have to be in the main directory, and type 'bikes' into Matlab (or octave)
% Normally the error when using the neural network should be ~15% better (The exact error depends on randInitializeWeights) when compared to the 'Mean Increment Model'
% I was able to push the error to ~16% when putting optimset('MaxIter', 50), but this makes the computational time start to get long (~30 min)
% The program has no knowledge of how many bikes are in the stations at the beginning of each week nor day when the test set is used. In theory, this information would make the error much better.

% Pour les fichiers:
% bikes.m			main program
% X.csv				all the day, date, time, weather, and temperature data read in and organized* (in that order)
% y.csv				all the bike data read in and organized* (bikes, free stations, percent of free stations, percent increase)
%
% et:
%
% fmincg.m			used to minimize the cost function
% lib				necessary matlab libraries
% meanIncrementModel.m		program for the 2nd part
% nnCostFunction.m		program for the 3rd part
% predict.m			predict the bike occupancy based on the neural network theta parameters (Theta1 & Theta2) and test data (X_test)
% randInitializeWeights.m	randomly initializes weights for the theta parameters (to avoid symmetric error in backprop)
% RMSE_test.m			computes the root mean square error
% sigmoid.m			sigmoid function
% sigmoidGradient.m		gradient of the sigmoid function
%
%
% *To begin I used a program (not included, but I can provide if desired) to read the file bordeaux_bikeshare_occupations.csv and bordeaux_weather.csv and find where there were holes in the data. After this I noted all the problematic dates in the variable 'missingDays' in bikes.m. Also there were some dates for which only two or three rows were missing. For these dates, I manually copied and pasted the dates to fill the holes. Finally the resulting files are X.csv and y.csv.

%============================================================================================================================================================
%============================================================================================================================================================
%============================================================================================================================================================
%FRENCH:

% Le program principale se trouve dans le fichier bikes.m
% Pour le lancer, il suffit just d'être dans la bonne directoire, et de tapper 'bikes' en Matlab (ou octave)
% Normalement l'erreur en utilisant le réseau de neuronaux doit être à l'entour de ~15% mieux (l'erreur exact dépand de randInitializeWeights) que celle avec le Mean Increment Model
% J'étais capable de le pousser à ~16% en mettre optimset('MaxIter', 50), mais ça commence à être un peu lourd au niveau de temps de calcul (~30 min)
% Aussi le programme n'a aucune info sur le nombre de vélos dans chaque station au début du jour ni semaine pour le test data. En théorie incluer cet info pourra ben améliorer l'erreur.

% Pour les fichiers:
% bikes.m			main program
% X.csv				all the day, date, time, weather, and temperature data read in and organized* (in that order)
% y.csv				all the bike data read in and organized* (bikes, free stations, percent of free stations, percent increase)
%
% et:
%
% fmincg.m			used to minimize the cost function
% lib				necessary matlab libraries
% meanIncrementModel.m		program for the 2nd part
% nnCostFunction.m		program for the 3rd part
% predict.m			predict the bike occupancy based on the neural network theta parameters (Theta1 & Theta2) and test data (X_test)
% randInitializeWeights.m	randomly initializes weights for the theta parameters (to avoid symmetric error in backprop)
% RMSE_test.m			computes the root mean square error
% sigmoid.m			sigmoid function
% sigmoidGradient.m		gradient of the sigmoid function
%
%
% *Pour les créer j'ai commencé par une programme (que je n'ai pas inclu, mais je peux vous envoyer si vous vouler) pour lire les fichiers bordeaux_bikeshare_occupations.csv et bordeaux_weather.csv et pour trouver où il y avait des trous dans les données. En suit j'ai noté tous les dates problématiques dans la variable 'missingDays' de bikes.m. Aussi, il y avait quelques dates pour lesquelles seulement deux ou trois rangs manquaient. Pour ces dates, j'ai copier et coller (à main) des dates pour remplir les trous. Finalement le résultat ce sont les fichiers X.csv et y.csv.
