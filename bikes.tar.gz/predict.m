function p = predict(Theta1, Theta2, test_X)
%PREDICT Predict the percentage of bikes at a station for a given input and a trained neural network
%   p = PREDICT(Theta1, Theta2, test_X) outputs the predicted label of X given the
%   trained weights of a neural network (Theta1, Theta2)

% Useful values
m = size(test_X, 1);
num_labels = size(Theta2, 1);

% p is our guess based on the neural network
p = zeros(size(test_X, 1), 1);

% Forwardprop
h1 = sigmoid([ones(m, 1) test_X] * Theta1');
h2 = sigmoid([ones(m, 1) h1] * Theta2');
p = max(h2, [], 2);


end
