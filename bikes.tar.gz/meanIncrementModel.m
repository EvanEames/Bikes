function [guess_y] = meanIncrementModel(train_X,train_y,test_X,test_y)
%MEAN INCREMENT MODEL Return the guess for bike numbers based on the `Mean Increment Model'

avgDeriv = zeros(7*24*4,1);
binEntries = zeros(7*24*4,1);
guess_y = zeros(size(test_X,1),1);

%Find the average increases for each times bin (7days*24h*4fifteenMinuteIntervals = 672 bins)
for i = 1:size(train_X,1)
	bin = train_X(i,1)*24*4 + train_X(i,3)/15 + 1;
	avgDeriv(bin) = avgDeriv(bin) + train_y(i,4);
	binEntries(bin)++;
end
avgDeriv = avgDeriv./binEntries;

%Now evolve the bike number through all of the test data
guess_y(1) = train_y(end,4);
for i = 2:size(test_X,1)
	numStations = sum(test_y(i,1:2));
	guess_y(i) = round(guess_y(i-1) + numStations*avgDeriv(test_X(i,1)*24*4 + test_X(i,3)/15 + 1));
	if (guess_y(i) > numStations) guess_y(i) = numStations; end %Make sure we haven't got too high
	if (guess_y(i) < 0) guess_y(i) = 0; end %Or too low
end

end
