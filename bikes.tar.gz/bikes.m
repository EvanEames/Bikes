%% Bordeau Bike Predictions
% Evan Eames 2018
% Note: The program nnCostFunction.m is modified from an old exersize from the Coursera Machine Learning module (Taught by Andrew Ng), and although I wrote the backprop algorithm, so some credit should go to him for designing the course.
%% =============================================================

%% Initialization
clear ; close all

%% Setup the neural network paremters
input_layer_size  = 5;  % Day, date, time, weather, temperature
hidden_layer_size = 25;   % 25 hidden units
num_labels = 1;          % 1 label, representing the percentage of stations that are full

%% Other useful stuff
monthDays = [0;31;59;90;120;151;181;212;243;273;304;334];
wWeights = [1 1 0.9 0.5 0.5 0.5]; %Sunny, clear, partly cloudy, cloudy, overcast, fog (everything else is 0)
missingDays = {'2012-06-30', '2012-07-01', '2012-07-02', '2012-07-03', '2012-07-04', '2012-07-06', '2012-12-08', '2012-12-09', '2012-12-10', '2012-12-11', '2012-12-19', '2017-07-06', '2013-01-17',  '2013-01-18', '2013-01-19', '2013-01-20', '2013-01-21', '2013-01-22', '2013-01-23', '2013-01-24', '2013-01-25', '2013-01-26', '2013-01-27', '2013-01-28', '2013-01-29', '2013-02-06', '2013-02-26', '2013-04-02', '2013-04-03', '2013-07-01', '2013-07-08', '2013-07-09', '2013-07-10', '2013-07-27', '2013-07-28', '2013-08-20', '2013-08-21', '2014-03-19', '2014-03-30' '2014-07-05', '2014-07-06', '2014-07-07', '2014-08-31', '2014-09-01', '2014-09-02' '2014-10-03', '2014-10-04', '2014-10-11', '2014-10-17', '2014-12-06', '2014-12-08', '2014-12-10', '2014-12-25', '2015-01-09', '2015-01-14', '2015-01-17', '2015-01-19', '2015-01-21', '2015-02-04', '2015-02-05', '2015-08-28', '2015-08-31', '2015-09-01'}; #Days missing bike or weather data

%% =============================================================
%% =========== Part 0: Loading and Organizing Data =============
%% =============================================================

% Which station do you want to focus on?
station = 42;

% If we haven't already, create a file for just that station
filename = strcat('station',int2str(station),'.csv');
filename2 = strcat('X.csv');
file1Status = exist(filename,'file')/2;
file2Status = exist(filename2,'file')/2;
if (!file1Status && !file2Status);
	nlines = 0;
	fprintf(strcat('Creating a file for station ',int2str(station),'. This could take a few minutes ...\n'));
	fid = fopen("bordeaux_bikeshare_occupations.csv", 'rt');
	fid2 = fopen(filename, 'w');
	while feof(fid) == 0
		tline = fgetl(fid);
		if (tline(21:22) == "42")
			fprintf(fid2,"%s\n",tline);
			nlines++;
		end
	end
	fclose(fid);
	fclose(fid2);
end

% If we haven't already, create a file for the organized data
if (!file2Status)
	fprintf('Reading in and organizing bike and weather data. This could take a few minutes ...\n');
	% A = readtable("bikes_test.csv",'Delimiter',{'-',' ',':',';'}); %(Not yet implemented in Octave!)
	A = importdata(filename,';',0);
	B = char(A.rowheaders);
	toDelete = find(ismember(B(:,1:10), missingDays)); %Find days without weather data
	B(toDelete,:) = []; %Delete days without weather data
	year = str2double(B(:,2:4));
	date = monthDays(str2double(B(:,6:7))) + str2double(B(:,9:10));
	% The date will be stored as (0 = sunday, 1 = monday, 2 = tuesday, ... , 6 = saturday)
	day = mod(date+(year-12),7); %The (year-12) term takes into account the fact that not very year starts on the same day. Will hold until feb 2016
	time = str2double(B(:,12:13))*60 + str2double(B(:,15:16)); %In minutes since 00:00
	y = real(A.data(:,3:4)); %Bike info
	y(toDelete,:) = []; %Delete days without weather data
	clear A;
	clear B;

	% Now we'll get the weather data
	W = importdata("bordeaux_weather.csv",';',1);
	toDelete = find(ismember(char(W.textdata(2:2:end,:))(:,1:10), missingDays)); %Find which rows correspond to days with missing data
	T = W.data(:,7); %Actually windchill, but trust me as a Canadian: that's more relevant
	w = char(W.textdata)(3:2:end,:); %This is for the weather conditions. Good weather = 1, bad weather = 0 (for the exact values see wWeights list above)
	w = (w(:,1) == 'S').*(w(:,2) == 'u')*wWeights(1) + ...
	 (w(:,1) == 'C').*(w(:,2) == 'l').*(w(:,3) == 'e')*wWeights(2) + ...
	 (w(:,1) == 'P').*(w(:,2) == 'a').*(w(:,3) == 'r')*wWeights(3) + ...
	 (w(:,1) == 'C').*(w(:,2) == 'l').*(w(:,3) == 'o')*wWeights(4) + ...
	 (w(:,1) == 'O')*wWeights(5) + ...
	 (w(:,1) == 'F')*wWeights(6);
	w(toDelete,:) = []; %Delete days without weather data
	T(toDelete,:) = []; %Delete days without weather data
	w = reshape([w w w w]',1,[])';
	T = reshape([T T T T]',1,[])';
	%Put it all together to make the full data set
	X = [day date time w(2:end-3) T(2:end-3)];

	% Save stuff so we don't have to do all this stuff again:
	csvwrite('X.csv',X);
	csvwrite('y.csv',y);
	clear W;
	clear w;
	clear toDelete;
else
	fprintf('Reading in previously saved data...\n');
	X = csvread('X.csv');
	y = csvread('y.csv');
end

% Let's also remove rows where the y = [0,0] (no bikes, nor empty spaces --> probably a bug).
toDelete = find(sum(y,2) == 0);
X(toDelete,:) = [];
y(toDelete,:) = [];

m = size(X, 1);

% Calculate the bike increment for each time, by first calculating the percentage of bikes present for a given time:
y = [y y(:,1)./(y(:,1)+y(:,2))]; %Add the percentage of stations full as a 3rd row.
deriv = zeros(m,1);
for i = 1:m-1
	if (X(i+1,2) - X(i,2) <= 1)
		deriv(i) = y(i+1,3) - y(i,3);
	else
		deriv(i) = y(i,3) - y(i-1,3);
	end
end

y = [y deriv];

% Seperate test and training data:
whereToCut = "2014-05-14 23:45:00";
dateToCut = monthDays(str2double(whereToCut(6:7))) + str2double(whereToCut(9:10));
timeToCut = str2double(whereToCut(12:13))*60 + str2double(whereToCut(15:16));
indexToCut = find((X(:,2) == dateToCut).*(X(:,3) == timeToCut) == 1)(str2double(whereToCut(3:4))-12);
train_X = X(1:indexToCut,:);
train_y = y(1:indexToCut,:);
test_X = X(indexToCut+1:end,:);
test_y = y(indexToCut+1:end,:);

%% =============================================================
%% ================ Part 1: Warm Up Challenge 1 ================
%% =============================================================

guess_y = ones(size(test_y,1),1)*X(1,1);
% Calculate Error
J1 = RMSE_test(guess_y,test_y(:,1));
fprintf('\nThe error for the Static Model is: %f ', J1);

fprintf('\nProgram paused. Press enter to continue.\n');
pause;

%% =============================================================
%% ================ Part 2: Warm Up Challenge 2 ================
%% =============================================================

guess_y = meanIncrementModel(train_X,train_y,test_X,test_y);
% Calculate Error
J2 = RMSE_test(guess_y,test_y(:,1));
fprintf('\nThe error for the Mean Increment Model is: %f ', J2);

fprintf('\nProgram paused. Press enter to continue.\n');
pause;

%% =======================================================================
%% ================ Part 3: Main Challenge (Hard version) ================
%% =======================================================================

fprintf('\nInitializing Neural Network Parameters ...\n')

initial_Theta1 = randInitializeWeights(input_layer_size, hidden_layer_size);
initial_Theta2 = randInitializeWeights(hidden_layer_size, num_labels);

% Unroll parameters
initial_nn_params = [initial_Theta1(:) ; initial_Theta2(:)];

fprintf('\nTraining Neural Network... \n')

options = optimset('MaxIter', 10);

% Regularization parameter
lambda = -0.2;

%Normalize the X labels (technically not necessary, but trains the neural network a bit faster)
X = X./max(X,[],1);
train_X = X(1:indexToCut,:);
test_X_nonNormalized = test_X; %For the expected_y file at the very end
test_X = X(indexToCut+1:end,:);

% Begin iteratively calculating the cost function and adjusting the Theta parameters
costFunction = @(p) nnCostFunction(p, input_layer_size, hidden_layer_size, num_labels, train_X, train_y(:,3), lambda);

[nn_params, cost] = fmincg(costFunction, initial_nn_params, options);

% Obtain Theta1 and Theta2 back from nn_params
Theta1 = reshape(nn_params(1:hidden_layer_size * (input_layer_size + 1)), hidden_layer_size, (input_layer_size + 1));

Theta2 = reshape(nn_params((1 + (hidden_layer_size * (input_layer_size + 1))):end), num_labels, (hidden_layer_size + 1));

guess_y = predict(Theta1, Theta2, test_X);

% We have the percentage of stations filled, so we just need to turn that into actual number of bikes
guess_y = round(guess_y.*sum(test_y(:,1:2),2));
% Make sure no station has more or less bikes than possible
for i = 2:size(test_X,1);
	numStations = sum(test_y(i,1:2));
	if (guess_y(i) > numStations) guess_y(i) = numStations; end %Make sure we haven't got too high
	if (guess_y(i) < 0) guess_y(i) = 0; end %Or too low
end

% New error
J3 = RMSE_test(guess_y,test_y(:,1));

fprintf('The error when trained with a Neural Network is: %f ', J3);
fprintf('\nThis is an improvement of %f percent over the Mean Increment Model', (1-(J3/J2))*100);
fprintf('\nThe expected bikes will now be written to the file expected_y.csv.');

csvwrite('expected_y.csv',[test_X_nonNormalized(:,1:3) guess_y]);

fprintf('\nProgram paused. Press enter to continue.\n');
pause;
