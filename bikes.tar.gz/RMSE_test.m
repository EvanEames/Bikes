function [J] = RMSE_test(guess_y, test_y)
%RMSE_TEST Returns the root-mean-square error between guess_y and y


m = size(test_y,1);
J = sqrt(sum((guess_y - test_y).^2)/m);

end
